
 module.exports = {
     
    // mongodb URI
    DB_URI: 'mongodb://Test:<PASSWORD>@cluster0-shard-00-00-vf6di.mongodb.net:27017,cluster0-shard-00-01-vf6di.mongodb.net:27017,cluster0-shard-00-02-vf6di.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true'

      
    }
    
    