
 const express = require('express');  // import express framework in node
 const  mongoose = require('mongoose'); //  for to connect to database
 const  config = require('./config/dev');


 mongoose.connect(config.DB_URI,{ useNewUrlParser: true });  // username and password entered into the URI

 const app = express(); // assigning app variable all the functions  required to run  server side application



 app.get('/rentals', function(req, res){ 
    try{
    res.json({'success': true });
    }
    catch(err){}
 });


// at localhost:3001 OR a assigned environment PORT is available,    function is be called when  application is running
const PORT = process.env.PORT || 3001;

//used to allow server-side code listen to front end functions
// at localhost:3001  is available,    function is be called when  application is running
app.listen(PORT, function(){ 
console.log('I am running!'); 
});



